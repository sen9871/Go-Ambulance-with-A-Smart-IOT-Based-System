<?php

require_once ('dbh.php');
$id = $_POST['id'];
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$icNo = $_POST['icNo'];
$gender = $_POST['gender'];
$age = $_POST['age'];
$date = $_POST['date'];


    $sql = "INSERT INTO `patient`(`id`, `firstName`, `lastName`, `icNo`, `gender`, `age`, `date`) VALUES ('','$firstName','$lastName','$icNo','$gender','$age','$date')";

    $result = mysqli_query($conn, $sql);


if(($result) == 1){
    
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Registered')
    window.location.href='..//assignproject.php';
    </SCRIPT>");
    //header("Location: ..//aloginwel.php");
}

else{
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Fail Registered')
    window.location.href='..//assignproject.php';
    </SCRIPT>");
 }





?>