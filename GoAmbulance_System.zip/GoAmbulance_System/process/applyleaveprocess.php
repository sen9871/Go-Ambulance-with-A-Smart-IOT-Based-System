<?php
//including the database connection file
require_once ('dbh.php');

//getting id of the data from url
$id = $_GET['id'];
//echo $id;
$address = $_POST['address'];
$vehiclePlateNo = $_POST['vehiclePlateNo'];
$registrationNo = $_POST['registrationNo'];
$driver = $_POST['driver'];
$state = $_POST['state'];
//echo "$reason";
$status = $_POST['status'];

$sql = "INSERT INTO `ambulance`(`id`,`vehiclePlateNo`, `registrationNo`, `driver`, `address`, `state`,`status`) VALUES ('','JHB3009','$registrationNo','Abdul Razil','$address','$state','Pending')";

$result = mysqli_query($conn, $sql);

//redirecting to the display page (index.php in our case)
header("Location:..//eloginwel.php?id=$id");
?>

