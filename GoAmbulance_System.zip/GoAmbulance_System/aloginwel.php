<?php 
require_once ('process/dbh.php');
$sql = "SELECT id, firstName, lastName,  gender, dept FROM employee";
$result = mysqli_query($conn, $sql);
?>


<html>
<head>
	<title>Admin Panel | Go-Ambulance System</title>
	<link rel="stylesheet" type="text/css" href="styleemplogin.css">
</head>
<body>
	
	<header>
		<nav>
			<h1>Go-Ambulance System</h1>
			<ul id="navli">
				<li><a class="homered" href="aloginwel.php">HOME</a></li>
				<li><a class="homeblack" href="addemp.php">Add User</a></li>
				<li><a class="homeblack" href="viewemp.php">View User</a></li>
				<li><a class="homeblack" href="assign.php">Add Patient</a></li>
				<li><a class="homeblack" href="assignproject.php">View Patient</a></li>
				<li><a class="homeblack" href="salaryemp.php">Ambulance Status</a></li>
				<li><a class="homeblack" href="empleave.php">Cloud Data</a></li>
				<li><a class="homeblack" href="alogin.html">Log Out</a></li>
			</ul>
		</nav>
	</header>
	 
	<div class="divider"></div>
	<div id="divimg">
		<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">User Leaderboard </h2>
    	<table>

			<tr bgcolor="#000">
				<th align = "center">Seq.</th>
				<th align = "center">Name</th>
				<th align = "center">Gender</th>
				<th align = "center">State</th>
				

			</tr>

			

			<?php
				$seq = 1;
				while ($employee = mysqli_fetch_assoc($result)) {
					echo "<tr>";
					echo "<td>".$seq."</td>";
					
					echo "<td>".$employee['firstName']." ".$employee['lastName']."</td>";
					
					echo "<td>".$employee['gender']."</td>";
					
					echo "<td>".$employee['dept']."</td>";
					$seq+=1;
				}


			?>

		</table>

		<div class="p-t-20">
			<button class="btn btn--radius btn--green" type="submit" style="float: right; margin-right: 60px"><a href="viewemp.php" style="text-decoration: none; color: white"> Edit User</button>
		</div>

		
	</div>
</body>
</html>