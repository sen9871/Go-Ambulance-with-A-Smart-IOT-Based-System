<?php

require_once ('process/dbh.php');
$sql = "SELECT * FROM `ambulance` ";

//echo "$sql";
$result = mysqli_query($conn, $sql);
if(isset($_POST['update']))
{

	$id = mysqli_real_escape_string($conn, $_POST['id']);
	$registrationNo = mysqli_real_escape_string($conn, $_POST['registrationNo']);
	$vehiclePlateNo = mysqli_real_escape_string($conn, $_POST['vehiclePlateNo']);
	$driver = mysqli_real_escape_string($conn, $_POST['driver']);
	$state = mysqli_real_escape_string($conn, $_POST['state']);
	$address = mysqli_real_escape_string($conn, $_POST['address']);
	$status = mysqli_real_escape_string($conn, $_POST['status']);





	// $result = mysqli_query($conn, "UPDATE `employee` SET `firstName`='$firstname',`lastName`='$lastname',`email`='$email',`password`='$email',`gender`='$gender',`contact`='$contact',`nid`='$nid',`salary`='$salary',`address`='$address',`dept`='$dept',`degree`='$degree' WHERE id=$id");


$result = mysqli_query($conn, "UPDATE `ambulance` SET `registrationNo`='$registrationNo',`vehiclePlateNo`='$vehiclePlateNo',`driver`='$driver',`address`='$address',`state`='$state',`status`='$status' WHERE id=$id");
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Updated')
    window.location.href='salaryemp.php';
    </SCRIPT>");


	
}
?>




<?php
	$id = (isset($_GET['id']) ? $_GET['id'] : '');
	$sql = "SELECT * from `ambulance` WHERE id=$id";
	$result = mysqli_query($conn, $sql);
	if($result){
	while($res = mysqli_fetch_assoc($result)){
	$vehiclePlateNo = $res['vehiclePlateNo'];
	$registrationNo = $res['registrationNo'];
	$driver = $res['driver'];
	$address = $res['address'];
	$state = $res['state'];
	$status = $res['status'];

	
}
}

?>

<html>
<head>
	<title>Update Ambulance Info |  Admin Panel | Go-Ambulance System</title>
	<!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>
<body>
	<header>
		<nav>
			<h1>Go-Ambulance System</h1>
			<ul id="navli">
				<li><a class="homeblack" href="aloginwel.php">HOME</a></li>s
				<li><a class="homeblack" href="salaryemp.php">View Ambulance Service Request</a></li>
				<li><a class="homered" href="editambulance.php">Update Ambulance Service</a></li>
				<li><a class="homeblack" href="elogin.html">Log Out</a></li>
			</ul>
		</nav>
	</header>
	
	<div class="divider"></div>
	
	<div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Update Ambulance Info</h2>
                    <form id = "registration" action="editambualnce.php" method="POST">

                            
                        <div class="input-group">
                                <input class="input--style-1" type="text" name="vehiclePlateNo" placeholder="Vehicle Plate No" value="<?php echo $vehiclePlateNo;?>" required="required" >
                        </div>
                           
                           
                        <div class="input-group">
                                <input class="input--style-1" type="text" name="registrationNo" placeholder="Vehicle Registration Number" value="<?php echo $registrationNo;?>" required="required">
                        </div>



                        <div class="input-group">
                            <input class="input--style-1" type="text" placeholder="Driver Name" name="driver" value="<?php echo $driver;?>" required="required">
                        </div>
                        

                        <div class="input-group">
                                <input class="input--style-1" type="text" placeholder="Address" name="address" value="<?php echo $address;?>">
                                   
                        </div>

                        <div class="input-group">
                            <input class="input--style-1" type="text" placeholder="State" name="state" value="<?php echo $state;?>">
                        </div>

                        <div class="input-group">
                            <input class="input--style-1" type="text" placeholder="Status" name="status" value="<?php echo $status;?>">
                        </div>

                        <input type="hidden" name="id" id="textField" value="<?php echo $id;?>" required="required"><br><br>
                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit" name="update">Submit</button>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>


     <!-- Jquery JS-->
    <!-- <script src="vendor/jquery/jquery.min.js"></script>
   
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

   
    <script src="js/global.js"></script> -->
</body>
</html>
