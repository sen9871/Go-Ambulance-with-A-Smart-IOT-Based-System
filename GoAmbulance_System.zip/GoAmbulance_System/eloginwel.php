<?php 
	$id = (isset($_GET['id']) ? $_GET['id'] : '');
	require_once ('process/dbh.php');
	 //$sql1 = "SELECT * FROM `ambulance` where id = '$id'";
	 //$result1 = mysqli_query($conn, $sql1);
	 //$employeen = mysqli_fetch_array($result1);
	// $empName = ($employeen['firstName']);

	 $sql = "SELECT * FROM `patient`";
	$sql1 = "SELECT * FROM `ambulance`";

	$sql2 = "Select * From employee, employee_leave Where employee.id = $id and employee_leave.id = $id order by employee_leave.token";

	$sql3 = "SELECT * FROM `salary` WHERE id = $id";

//echo "$sql";
$result = mysqli_query($conn, $sql);
$result1 = mysqli_query($conn, $sql1);
$result2 = mysqli_query($conn, $sql2);
$result3 = mysqli_query($conn, $sql3);
?>



<html>
<head>
	<title>User Panel | Go-Ambulance System</title>
	<link rel="stylesheet" type="text/css" href="styleemplogin.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster|Montserrat" rel="stylesheet">
</head>
<body>
	
	<header>
		<nav>
			<h1>Go-Ambulance System</h1>
			<ul id="navli">
				<li><a class="homered" href="eloginwel.php?id=<?php echo $id?>"">HOME</a></li>
				<li><a class="homeblack" href="myprofile.php?id=<?php echo $id?>"">My Profile</a></li>
				<li><a class="homeblack" href="empproject.php?id=<?php echo $id?>"">Report</a></li>
				<li><a class="homeblack" href="applyleave.php?id=<?php echo $id?>"">Apply Ambulance</a></li>
				<li><a class="homeblack" href="elogin.html">Log Out</a></li>
			</ul>
		</nav>
	</header>
	 
	<div class="divider"></div>
	<div id="divimg">
	<div>
		<!-- <h2>Welcome <?php echo "$empName"; ?> </h2> -->

		    	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Patient Leaderboard </h2>
    	<table>

			<tr bgcolor="#000">
				<th align = "center">Seq.</th>
				<th align = "center">Name</th>
				<th align = "center">IC No</th>
				<th align = "center">Gender</th>
				<th align = "center">Age</th>
				<th align = "center">Date Hospitalize</th>
				

			</tr>

			

			<?php
				$seq = 1;
				while ($employee = mysqli_fetch_assoc($result)) {
					echo "<tr>";
					echo "<td>".$seq."</td>";
					
					echo "<td>".$employee['firstName']." ".$employee['lastName']."</td>";
					echo "<td>".$employee['icNo']."</td>";
					echo "<td>".$employee['gender']."</td>";
					echo "<td>".$employee['age']."</td>";
					echo "<td>".$employee['date']."</td>";
					
					$seq+=1;
				}


			?>

		</table>
   




		<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Ambulance Status</h2>
    	

    	<table>

			<tr>
				<th align = "center">Ambulance Plate No</th>
				
				<th align = "center">Driver</th>
				<th align = "center">Hospital Area</th>
				<th align = "center">State</th>
				<th align = "center">Status</th>
			</tr>

			

			<?php
				while ($ambulance = mysqli_fetch_assoc($result1)) {

					echo "<tr>";

					
					
					echo "<td>".$ambulance['vehiclePlateNo']."</td>";
					
					echo "<td>".$ambulance['driver']."</td>";
					echo "<td>".$ambulance['address']."</td>";
					echo "<td>".$ambulance['state']."</td>";
					echo "<td>".$ambulance['status']."</td>";
					
				}


				


			?>

		</table>

   
<br>
<br>
<br>
<br>
<br>







	</div>


		</h2>


		
		
	</div>
</body>
</html>