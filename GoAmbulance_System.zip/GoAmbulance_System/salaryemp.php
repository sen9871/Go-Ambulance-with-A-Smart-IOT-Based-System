<?php

require_once ('process/dbh.php');
$sql = "SELECT * from `ambulance` ";

//echo "$sql";
$result = mysqli_query($conn, $sql);

?>



<html>
<head>
	<title>Ambulance Status |  Admin Panel | Go-Ambulance System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
</head>
<body>
	<header>
		<nav>
			<h1>Go-Ambulance System</h1>
			<ul id="navli">
				<li><a class="homeblack" href="aloginwel.php">HOME</a></li>
				<li><a class="homeblack" href="addemp.php">Add User</a></li>
				<li><a class="homeblack" href="viewemp.php">View User</a></li>
				<li><a class="homeblack" href="assign.php">Add Patient</a></li>
				<li><a class="homeblack" href="assignproject.php">View Patient</a></li>
				<li><a class="homered" href="salaryemp.php">Ambulance Status</a></li>
				<li><a class="homeblack" href="empleave.php">Cloud Data</a></li>
				<li><a class="homeblack" href="alogin.html">Log Out</a></li>
			</ul>
		</nav>
	</header>
	
	<div class="divider"></div>

		<table>
			<tr>

				<th align = "center">Ambulance ID</th>
				<th align = "center">Ambulance Plate No</th>
				<th align = "center">Vehicle Registration No</th>
				<th align = "center">Driver</th>
				<th align = "center">Hospital Area</th>
				<th align = "center">State</th>
				<th align = "center">Status</th>
				
				<th align = "center">Options</th>
			</tr>

			<?php
				while ($ambulance = mysqli_fetch_assoc($result)) {
					echo "<tr>";
					echo "<td>".$ambulance['id']."</td>";
					echo "<td>".$ambulance['vehiclePlateNo']."</td>";
					echo "<td>".$ambulance['registrationNo']."</td>";
					echo "<td>".$ambulance['driver']."</td>";
					echo "<td>".$ambulance['address']."</td>";
					echo "<td>".$ambulance['state']."</td>";
					echo "<td>".$ambulance['status']."</td>";

					echo "<td><a href=\"approveambulance.php?id=$ambulance[id]\"  onClick=\"return confirm('Are you sure you want to Approve the request?')\">Approve</a> | <a href=\"editambualnce.php?id=$ambulance[id]\">Edit</a> | <a href=\"cancelambulance.php?id=$ambulance[id]\" onClick=\"return confirm('Are you sure you want to Canel the request?')\">Cancel</a></td>";
				}


			?>

		</table>
		
	
</body>
</html>