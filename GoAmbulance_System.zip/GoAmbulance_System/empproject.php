<?php 
	$id = (isset($_GET['id']) ? $_GET['id'] : '');
	require_once ('process/dbh.php');
	$sql = "SELECT * FROM `project` where eid = '$id'";
	$result = mysqli_query($conn, $sql);
	
?>



<html>
<head>
	<title>User Panel | Go-Ambulance System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
</head>
<body>
	
	<header>
		<nav>
			<h1>Go-Ambulance System</h1>
			<ul id="navli">
				<li><a class="homeblack" href="eloginwel.php?id=<?php echo $id?>"">HOME</a></li>
				<li><a class="homeblack" href="myprofile.php?id=<?php echo $id?>"">My Profile</a></li>
				<li><a class="homered" href="empproject.php?id=<?php echo $id?>"">Report</a></li>
				<li><a class="homeblack" href="applyleave.php?id=<?php echo $id?>"">Apply Ambulance</a></li>
				<li><a class="homeblack" href="elogin.html">Log Out</a></li>
			</ul>
		</nav>
	</header>
	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Collision Impact of A Vehicle </h2>
	<br>
	<center>
	<iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1735582/charts/1?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&type=line&update=15"></iframe>
	</center>
	<br>
	<center><iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1735582/widgets/476358"></iframe></center>
	<br><br>
	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Button State of Push Button </h2>
	<br>
	<center>
	<iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1735582/charts/2?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&title=Button+State+of+Push+Button&type=line"></iframe>
	</center>
	<br>
	<center>
	<iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1735582/widgets/476359"></iframe>
	</center>	
		
</body>
</html>