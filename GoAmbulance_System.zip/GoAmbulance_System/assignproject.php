<?php

require_once ('process/dbh.php');
$sql = "SELECT * from `patient` ";

//echo "$sql";
$result = mysqli_query($conn, $sql);

?>



<html>
<head>
	<title>View Patient |  Admin Panel | Go-Ambulance System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
</head>
<body>
	<header>
		<nav>
			<h1>Go-Ambulance System</h1>
			<ul id="navli">
				<li><a class="homeblack" href="aloginwel.php">HOME</a></li>
				<li><a class="homeblack" href="addemp.php">Add User</a></li>
				<li><a class="homeblack" href="viewemp.php">View User</a></li>
				<li><a class="homeblack" href="assign.php">Add Patient</a></li>
				<li><a class="homered" href="assignproject.php">View Patient</a></li>
				<li><a class="homeblack" href="salaryemp.php">Ambulance Status</a></li>
				<li><a class="homeblack" href="empleave.php">Cloud Data</a></li>
				<li><a class="homeblack" href="alogin.html">Log Out</a></li>
			</ul>
		</nav>
	</header>
	
	<div class="divider"></div>

		<table>
			<tr>

				<th align = "center">Patient ID</th>
				<th align = "center">Name</th>
				<th align = "center">IC Number</th>
				<th align = "center">Gender</th>
				<th align = "center">Age</th>
				<th align = "center">date</th>

				<th align = "center">Options</th>
			</tr>

			<?php
				while ($patient = mysqli_fetch_assoc($result)) {
					echo "<tr>";
					echo "<td>".$patient['id']."</td>";
					echo "<td>".$patient['firstName']." ".$patient['lastName']."</td>";
					echo "<td>".$patient['icNo']."</td>";
					echo "<td>".$patient['gender']."</td>";
					echo "<td>".$patient['age']."</td>";
					echo "<td>".$patient['date']."</td>";

					echo "<td><a href=\"editpatient.php?id=$patient[id]\">Edit</a> | <a href=\"deletepatient.php?id=$patient[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";


				}


			?>

		</table>
		
	
</body>
</html>