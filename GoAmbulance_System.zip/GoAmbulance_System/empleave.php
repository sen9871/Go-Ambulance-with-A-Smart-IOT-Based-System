<?php

require_once ('process/dbh.php');

//$sql = "SELECT * from `employee_leave`";
$sql = "Select employee.id, employee.firstName, employee.lastName, employee_leave.start, employee_leave.end, employee_leave.reason, employee_leave.status, employee_leave.token From employee, employee_leave Where employee.id = employee_leave.id order by employee_leave.token";

//echo "$sql";
$result = mysqli_query($conn, $sql);

?>



<html>
<head>
	<title>Cloud Data | Admin Panel | Go-Ambulance System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
</head>
<body>
	
	<header>
		<nav>
			<h1>Go-Ambulance System</h1>
			<ul id="navli">
				<li><a class="homeblack" href="aloginwel.php">HOME</a></li>
				
				<li><a class="homeblack" href="addemp.php">Add User</a></li>
				<li><a class="homeblack" href="viewemp.php">View User</a></li>
				<li><a class="homeblack" href="assign.php">Add Patient</a></li>
				<li><a class="homeblack" href="assignproject.php">View Patient</a></li>
				<li><a class="homeblack" href="salaryemp.php">Ambulance Status</a></li>
				<li><a class="homered" href="empleave.php">Cloud Data</a></li>
				<li><a class="homeblack" href="alogin.html">Log Out</a></li>
			</ul>
		</nav>
	</header>
	 
	<div class="divider"></div>
	<div id="divimg">
	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Collision Impact of A Vehicle </h2>
	<br>
	<center>
	<iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1735582/charts/1?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&type=line&update=15"></iframe>
	</center>
	<br>
	<center><iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1735582/widgets/476358"></iframe></center>
	<br><br>
	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Button State of Push Button </h2>
	<br>
	<center>
	<iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1735582/charts/2?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&title=Button+State+of+Push+Button&type=line"></iframe>
	</center>
	<br>
	<center>
	<iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1735582/widgets/476359"></iframe>
	</center>	
	</div>
</body>
</html>